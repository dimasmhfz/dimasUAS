package com.yurani.resto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
