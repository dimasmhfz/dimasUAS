
class AuthUtils {
  static AuthUtils instance = AuthUtils();

  //* Insert with your Zoomato API KEY
  Future getToken() async {
    return "<YOUR ZOOMATO API KEY>";
  }

}
