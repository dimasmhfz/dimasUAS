import 'package:intl/intl.dart';

final formatter = new NumberFormat("#,###");
